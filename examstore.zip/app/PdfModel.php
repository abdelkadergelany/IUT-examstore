<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PdfModel extends Model
{
    //
    protected $guarded = ['id'];

}
