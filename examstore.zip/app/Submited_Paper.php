<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Submited_Paper extends Model
{
    //
    protected $guarded = ['id'];

}
