export const FETCH_EXAMS = 'FETCH_EXAMS';
export const APPLY_FILTERS = 'APPLY_FILTERS';
export const ADD_TO_FAVORITE = 'ADD_TO_FAVORITE';
export const FETCH_FAVORITE = 'FETCH_FAVORITE';
export const SUBMIT_PAPER = 'SUBMIT_PAPER';
export const SET_SEMESTER = 'SET_SEMESTER';
export const SET_DEPT = 'SET_DEPT';
export const SET_TYPE = 'SET_TYPE';
export const SET_YEAR = 'SET_YEAR';
export const GET_TYPE = 'GET_TYPE';
export const GET_YEAR = 'GET_YEAR';
export const SET_FILTER = 'SET_FILTER';






